VITAN CONSTRUCT — prima versiune a site-ului

Fișier principal: index.html

Contact:
- Telefon: 0769105363
- WhatsApp: 0767429398

Zone:
- Buzău și împrejurimi
- Râmnicu Sărat și împrejurimi
- Brăila și împrejurimi

Pentru publicare, încarcă index.html într-un serviciu de hosting static (de exemplu GitHub Pages).
Înainte de promovare, completează galeria cu fotografii reale, verifică datele de contact și adaugă doar servicii pe care le poți executa.
